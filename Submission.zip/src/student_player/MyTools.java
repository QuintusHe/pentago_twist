package student_player;

public class MyTools {
    public static double getSomething() {
        return Math.random();
    }
}